package com.starhub.prepaidreport.swingapp;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.http.*;
import org.springframework.web.client.RestTemplate;

import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;

public class MsisdnApiClient {

    private final RestTemplate restTemplate;
    private final ObjectMapper objectMapper;

    public MsisdnApiClient() {
        this.restTemplate = new RestTemplate();
        this.objectMapper = new ObjectMapper();
    }

    public JsonNode getApiResult(String msisdn, String csrfToken, String jsessionId) {
        try {
            String decodedCsrf = URLDecoder.decode(csrfToken, StandardCharsets.UTF_8.name());
            String url = "https://ppd.starhub.com/prvsportal/report/presimrptsearch.json"
                    + "?msisdn=" + msisdn
                    + "&CSRFToken=" + decodedCsrf;

            HttpHeaders headers = new HttpHeaders();
            headers.set("Cookie", "JSESSIONID=" + jsessionId);
            headers.set("User-Agent", "Mozilla/5.0");
            headers.set("Referer", "https://ppd.starhub.com/prvsportal/prepaid_sim_search_report.htm");
            headers.set("X-Requested-With", "XMLHttpRequest");
            headers.setAccept(MediaType.parseMediaTypes("application/json"));

            HttpEntity<Void> entity = new HttpEntity<>(headers);
            ResponseEntity<String> response = restTemplate.exchange(
                    url,
                    HttpMethod.GET,
                    entity,
                    String.class
            );

            return objectMapper.readTree(response.getBody()).path("result");

        } catch (Exception e) {
            e.printStackTrace();
            return objectMapper.createArrayNode();
        }
    }
}
