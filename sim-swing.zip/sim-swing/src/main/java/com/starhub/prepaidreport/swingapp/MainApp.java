package com.starhub.prepaidreport.swingapp;

import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import java.awt.GridLayout;
import java.io.File;

public class MainApp {

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("MSISDN Excel Processor");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setSize(500, 300);
            frame.setLocationRelativeTo(null);

            JPanel panel = new JPanel(new GridLayout(5, 1, 10, 10));

            JTextField csrfField = new JTextField();
            JTextField jsessionField = new JTextField();
            JButton chooseFileButton = new JButton("Choose Excel File");
            JLabel chosenFileLabel = new JLabel("No file selected");
            JButton processButton = new JButton("Process and Save");
            JFileChooser fileChooser = new JFileChooser();

            final File[] selectedFile = new File[1];

            chooseFileButton.addActionListener(e -> {
                int result = fileChooser.showOpenDialog(frame);
                if (result == JFileChooser.APPROVE_OPTION) {
                    selectedFile[0] = fileChooser.getSelectedFile();
                    chosenFileLabel.setText(selectedFile[0].getName());
                }
            });

            processButton.addActionListener(e -> {
                if (selectedFile[0] == null) {
                    JOptionPane.showMessageDialog(frame, "Please select a file.");
                    return;
                }
                try {
                    MsisdnService service = new MsisdnService(new MsisdnApiClient());
                    File output = service.processExcel(selectedFile[0], csrfField.getText(), jsessionField.getText());
                    JOptionPane.showMessageDialog(frame, "File saved: " + output.getAbsolutePath());
                } catch (Exception ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(frame, "Error: " + ex.getMessage());
                }
            });

            panel.add(new JLabel("CSRF Token:"));
            panel.add(csrfField);
            panel.add(new JLabel("JSESSIONID:"));
            panel.add(jsessionField);
            panel.add(chooseFileButton);
            panel.add(chosenFileLabel);
            panel.add(processButton);

            frame.add(panel);
            frame.setVisible(true);
        });
    }
}
