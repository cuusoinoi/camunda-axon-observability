package com.starhub.prepaidreport.swingapp;

import com.fasterxml.jackson.databind.JsonNode;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.RichTextString;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class MsisdnService {

    private final MsisdnApiClient apiClient;

    public MsisdnService(MsisdnApiClient apiClient) {
        this.apiClient = apiClient;
    }

    public File processExcel(File inputFile, String csrfToken, String jsessionId) throws Exception {
        Workbook workbook = new XSSFWorkbook(new FileInputStream(inputFile));
        Sheet sheet = workbook.getSheetAt(0);

        Row header = sheet.getRow(0);
        int prepaidIdx = -1, identityIdx = -1, customerIdx = -1;
        for (Cell cell : header) {
            String val = cell.getStringCellValue().toLowerCase();
            if (val.contains("prepaid")) prepaidIdx = cell.getColumnIndex();
            if (val.contains("identity")) identityIdx = cell.getColumnIndex();
            if (val.contains("customer")) customerIdx = cell.getColumnIndex();
        }

        DataFormatter formatter = new DataFormatter();

        for (int i = 1; i <= sheet.getLastRowNum(); i++) {
            Row row = sheet.getRow(i);
            if (row == null) continue;

            String msisdn = formatter.formatCellValue(row.getCell(prepaidIdx));
            JsonNode results = apiClient.getApiResult(msisdn, csrfToken, jsessionId);

            Cell identityCell = row.getCell(identityIdx, Row.MissingCellPolicy.CREATE_NULL_AS_BLANK);
            Cell customerCell = row.getCell(customerIdx, Row.MissingCellPolicy.CREATE_NULL_AS_BLANK);

            if (!results.isEmpty()) {
                JsonNode latest = getLatest(results);
                String subId = latest.path("subid").asText();
                String subName = latest.path("subname").asText();
                boolean isNameDifferent = !subName.equalsIgnoreCase(customerCell.getStringCellValue());

                appendToCell(identityCell, subId, isNameDifferent || "N/A".equalsIgnoreCase(subId));
                appendToCell(customerCell, subName, isNameDifferent || "N/A".equalsIgnoreCase(subName));
            } else {
                appendToCell(identityCell, "N/A", true);
                appendToCell(customerCell, "N/A", true);
            }
        }

        File output = new File("output_" + System.currentTimeMillis() + ".xlsx");
        try (FileOutputStream out = new FileOutputStream(output)) {
            workbook.write(out);
        }
        workbook.close();
        return output;
    }

    private void appendToCell(Cell cell, String newValue, boolean makeRed) {
        String old = cell.getStringCellValue();
        String fullText = old.isEmpty() ? newValue : old + "\n" + newValue;

        RichTextString richText = cell.getSheet().getWorkbook().getCreationHelper().createRichTextString(fullText);

        Font blackFont = cell.getSheet().getWorkbook().createFont();
        blackFont.setColor(IndexedColors.BLACK.getIndex());

        Font redFont = cell.getSheet().getWorkbook().createFont();
        redFont.setColor(IndexedColors.RED.getIndex());

        if (!old.isEmpty()) {
            richText.applyFont(0, old.length(), blackFont);
            richText.applyFont(old.length(), fullText.length(), makeRed ? redFont : blackFont);
        } else {
            richText.applyFont(0, fullText.length(), makeRed ? redFont : blackFont);
        }

        cell.setCellValue(richText);
    }

    private JsonNode getLatest(JsonNode array) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss");
        JsonNode latest = null;
        LocalDateTime latestDate = null;

        for (JsonNode node : array) {
            String lastModified = node.path("lastmodifieddate").asText();
            String fallbackDate = node.path("datetime").asText();

            try {
                LocalDateTime date = LocalDateTime.parse(
                        lastModified.isEmpty() ? fallbackDate : lastModified,
                        formatter
                );
                if (latestDate == null || date.isAfter(latestDate)) {
                    latestDate = date;
                    latest = node;
                }
            } catch (Exception ignored) {
            }
        }
        return latest;
    }
}
